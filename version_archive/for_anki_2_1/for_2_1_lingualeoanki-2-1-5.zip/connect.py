import os
from .six.moves import http_cookiejar
from .six.moves import urllib
import socket
import json
import ssl

from aqt.qt import *
from . import utils


class Lingualeo(QObject):
    Error = pyqtSignal(str)

    def __init__(self, email, password, cookies_path=None, parent=None):
        QObject.__init__(self, parent)
        self.email = email
        self.password = password
        self.cj = http_cookiejar.MozillaCookieJar()
        if cookies_path:
            self.cookies_path = cookies_path
            if not os.path.exists(cookies_path):
                self.save_cookies()
            else:
                try:
                    self.cj.load(cookies_path)
                except (IOError, TypeError, ValueError):
                    # TODO: process exceptions separately
                    self.cj = http_cookiejar.MozillaCookieJar()
                except:
                    # TODO: Handle corrupt cookies loading
                    self.cj = http_cookiejar.MozillaCookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.cj))
        config = utils.get_config()
        self.url_prefix = 'https://'
        self.msg = ''
        self.tried_ssl_fix = False

    def get_connection(self):
        try:
            if not self.is_authorized():
                status = self.auth()
                if status['error_msg']:
                    self.msg = status['error_msg']
        except (urllib.error.URLError, socket.error) as e:
            # TODO: Find better (secure) fix
            """
            SSLError was noticed on MacOS, because Python 3.6m used in Anki doesn't have 
            security certificates downloaded. The easiest (but unsecure) way is to create SSL context.
            """
            if 'SSL' in str(e.args) and not self.tried_ssl_fix:
                # Problem with https connection, trying ssl fix
                # TODO: check if necessary to create empty cookies
                # self.cj = http_cookiejar.MozillaCookieJar()

                https_handler = urllib.request.HTTPSHandler(context=ssl._create_unverified_context())
                self.opener = urllib.request.build_opener(https_handler, urllib.request.HTTPCookieProcessor(self.cj))
                self.tried_ssl_fix = True
                return self.get_connection()
            else:
                self.msg = "Can't authorize. Problems with internet connection. Error message: " + str(e.args)
        except ValueError:
            self.msg = "Error! Possibly, invalid data was received from LinguaLeo"
        except Exception as e:
            self.msg = "There's been an unexpected error. Please copy the error message and create a new issue " \
                       "on GitHub (https://github.com/vi3itor/lingualeoanki/issues/new). Error: " + str(e.args)
        if self.msg:
            self.Error.emit(self.msg)
            self.msg = ''
            return False
        return True

    def get_wordsets(self):
        """
        Get user's dictionaries (wordsets), including default ones,
        and return those, that are not empty
        """
        if not self.get_connection():
            return None
        try:
            url = 'mobile-api.lingualeo.com/GetWordSets'
            values = {'apiVersion': '1.0.0',
                      'request': [{'type': 'user', 'perPage': 999, 'sortBy': 'created'}]}
            all_wordsets = self.get_content_new(url, values)['data'][0]['items']
            wordsets = []
            # Add only non-empty dictionaries
            for wordset in all_wordsets:
                """
                Apparently, first dictionary has attribute 'countWords', 
                while others has attribute 'cw'
                """
                if 'cw' in wordset and wordset['cw'] != 0:
                    wordsets.append(wordset.copy())
                elif 'countWords' in wordset and wordset['countWords'] != 0:
                    wordsets.append(wordset.copy())
            self.save_cookies()
            if not wordsets:
                self.msg = 'No user dictionaries found'
        except (urllib.error.URLError, socket.error):
            self.msg = "Can't get dictionaries. Problem with internet connection."
        except ValueError:
            self.msg = "Error! Possibly, invalid data was received from LinguaLeo"
        except Exception as e:
            self.msg = "There's been an unexpected error. Please copy the error message and create a new issue " \
                       "on GitHub (https://github.com/vi3itor/lingualeoanki/issues/new). Error: " + str(e.args)
        if self.msg:
            self.Error.emit(self.msg)
            self.msg = ''
            return None
        return wordsets

    def get_words_to_add(self, status, wordsets=None):
        if not self.get_connection():
            return None
        try:
            words = []
            if not wordsets:
                words = self.get_words(status, None)
            else:
                for wordset in wordsets:
                    words += self.get_words(status, wordset)
            self.save_cookies()
            # print("Found {} words".format(len(words)))
        except (urllib.error.URLError, socket.error):
            self.msg = "Can't download words. Problem with internet connection."
        except ValueError:
            self.msg = "Error! Possibly, invalid data was received from LinguaLeo"
        except Exception as e:
            self.msg = "There's been an unexpected error. Please copy the error message and create a new issue " \
                       "on GitHub (https://github.com/vi3itor/lingualeoanki/issues/new). Error: " + str(e.args)
        if self.msg:
            self.Error.emit(self.msg)
            self.msg = ''
            return None

        return words

    def get_words(self, status, wordset):
        """
        Get words either from main ('my') vocabulary or from user's dictionaries (wordsets)
        Response data consists of word groups that are separated by date.
        Each word group has:
        groupCount - number of words in the group,
        groupName - name of the group, like 'new' or 'year_2' (stands for 2 years ago),
        words - list of words (not more than PER_PAGE)
        :param status: progress status of the word: 'all', 'new', 'learning', learned'
        :param wordset: A wordset, or None to download all words (from main dictionary)
        :return: list of words, where each word is a dict
        """
        url = 'mobile-api.lingualeo.com/GetWords'
        # TODO: Move parameter to config?
        PER_PAGE = 100
        values = {'apiVersion': '1.0.1', 'api_call': 'GetWords',
                  'dateGroup': 'start', 'mode': 'basic',
                  'perPage': PER_PAGE, 'status': status}
        # New API requires list of attributes
        values.update(ATTRIBUTE_LIST)
        # ID of the main (my) dictionary is 1
        values['wordSetId'] = wordset.get('id') if wordset else 1

        words = []
        date_group = 'start'
        offset = {}

        words_received = 0
        total = 0
        extra_date_group = date_group  # to get into the while loop

        # Request the words until
        while words_received > 0 or extra_date_group:
            if words_received == 0 and extra_date_group:
                values['dateGroup'] = extra_date_group
                values['offset'] = {}
                extra_date_group = None
            else:
                values['dateGroup'] = date_group
                values['offset'] = offset
            response = self.get_content_new(url, values)
            word_groups = response.get('data')
            if response.get('error') or not word_groups:
                raise Exception('Incorrect data received from LinguaLeo. Possibly API has been changed again. '
                                + response.get('error'))
            words_received = 0
            for word_group in word_groups:
                word_chunk = word_group.get('words')
                if word_chunk:
                    words += word_chunk
                    words_received += len(word_chunk)
                    date_group = word_group.get('groupName')
                    offset['wordId'] = word_group.get('words')[-1].get('id')
                elif words_received > 0:
                    ''' 
                    If the next word_chunk is empty, and we completed the previous, 
                    next response should be to the next group
                    '''
                    if words_received < PER_PAGE:
                        date_group = word_group.get('groupName')
                        extra_date_group = None
                        offset = {}
                    else:  # words_received == PER_PAGE
                        '''We either need to continue with this group or try the next'''
                        extra_date_group = word_group.get('groupName')
                    break
            total += words_received
            # print('Received {} words. Total: {}.'.format(words_received, total))
        return words

    def save_cookies(self):
        if hasattr(self, 'cookies_path'):
            self.cj.save(self.cookies_path)

    def get_token(self):
        if hasattr(self, 'token'):
            return self.token
        for cookie in self.cj:
            if cookie.name == 'remember':
                self.token = cookie.value
                return self.token

    # Low level methods
    #########################

    def get_content_new(self, url, more_values):
        """
        A new API method to request content
        """
        values = {'token': self.get_token()}
        values.update(more_values)
        full_url = self.url_prefix + url
        json_data = json.dumps(values)
        data = json_data.encode('utf-8')
        req = urllib.request.Request(full_url)
        req.add_header('Content-Type', 'text/plain')
        if self.tried_ssl_fix:
            # Have to do it on MacOS for now
            response = urllib.request.urlopen(req, data=data, context=ssl._create_unverified_context())
        else:
            # Default behavior
            response = urllib.request.urlopen(req, data=data)
        return json.loads(response.read())

    """
    Using requests module (only in Anki 2.1) it can be performed as:

    def requests_get_content(self, url, data):
        full_url = self.url_prefix + url
        headers = {'Content-Type': 'text/plain'}
        r = requests.post(full_url, json=data, headers=headers)
        # print(r.status_code)
        return r.json()
    """

    """
    OLD API Methods. Used for authorization
    """

    def auth(self):
        url = 'api.lingualeo.com/api/login'
        values = {'email': self.email, 'password': self.password}
        content = self.get_content(url, values)
        self.save_cookies()
        self.get_token()
        return content

    def is_authorized(self):
        url = 'api.lingualeo.com/api/isauthorized'
        status = self.get_content(url, None)['is_authorized']
        return status

    def get_content(self, url, values):
        if values:
            url_values = urllib.parse.urlencode(values)
            data = url_values.encode('utf-8')
        else:
            data = None
        full_url = self.url_prefix + url  # + '?' + url_values if url_values else self.url_prefix + url
        req = self.opener.open(full_url, data=data)
        return json.loads(req.read())

    # TODO: Add processing of http status codes in exceptions,
    #  see: http://docs.python-requests.org/en/master/user/quickstart/#response-status-codes


class Download(QThread):
    Length = pyqtSignal(int)
    Counter = pyqtSignal(int)
    FinalCounter = pyqtSignal(int)
    Word = pyqtSignal(dict)
    Error = pyqtSignal(str)

    def __init__(self, words, parent=None):
        QThread.__init__(self, parent)
        self.words = words

    def run(self):
        self.Length.emit(len(self.words))
        self.add_separately()

    def add_separately(self):
        """
        Divides downloading and filling note to different threads
        because you cannot create SQLite objects outside the main
        thread in Anki. Also you cannot download files in the main
        thread because it will freeze GUI
        """
        counter = 0
        problem_words = []

        for word in self.words:
            self.Word.emit(word)
            try:
                # print('Downloading media for word: {}'.format(word.get('wordValue')))
                utils.send_to_download(word, self)
            except (urllib.error.URLError, socket.error):
                problem_words.append(word.get('wordValue'))
            counter += 1
            self.Counter.emit(counter)
        self.FinalCounter.emit(counter)

        # TODO: save problem words in json format to user_files folder
        #  and ask user to retry downloading problem words

        if problem_words:
            self.problem_words_msg(problem_words)

    def problem_words_msg(self, problem_words):
        error_msg = ("We weren't able to download media for these "
                     "words because of broken links in LinguaLeo "
                     "or problems with an internet connection: ")
        for problem_word in problem_words[:-1]:
            error_msg += problem_word + ', '
        error_msg += problem_words[-1] + '.'
        self.Error.emit(error_msg)


ATTRIBUTE_LIST = {"attrList":
                      {
                          "id": "id",
                          "wordValue": "wd",
                          "origin": "wo",
                          "wordType": "wt",
                          "translations": "trs",
                          "wordSets": "ws",
                          "created": "cd",
                          "learningStatus": "ls",
                          "progress": "pi",
                          "transcription": "scr",
                          "pronunciation": "pron",
                          "relatedWords": "rw",
                          "association": "as",
                          "trainings": "trainings",
                          "listWordSets": "listWordSets",
                          "combinedTranslation": "trc",
                          "picture": "pic",
                          "speechPartId": "pid",
                          "wordLemmaId": "lid",
                          "wordLemmaValue": "lwd"
                      }
}