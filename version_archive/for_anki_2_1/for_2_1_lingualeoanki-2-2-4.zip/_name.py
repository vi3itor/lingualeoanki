"""
Defines name of the add-on
"""

ADDON_NAME = 'lingualeoanki'
