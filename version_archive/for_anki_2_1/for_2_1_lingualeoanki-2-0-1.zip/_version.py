"""
Defines version of the add-on
"""

VERSION = '2.0.1'
