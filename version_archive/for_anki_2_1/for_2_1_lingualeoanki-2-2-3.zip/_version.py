"""
Defines version of the add-on
"""

# Make sure to use single quotes here
VERSION = '2.2.3'
